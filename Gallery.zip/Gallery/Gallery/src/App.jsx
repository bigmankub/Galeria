import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const images = [
    {id:1, title:"Zdjęcie 1", url:"https://wallpapers.com/images/high/retro-colorful-nightscape-city-buildings-4k-obfdnkrnmb0v5keb.webp"},
    {id:2, title:"Zdjęcie 2", url:"https://wallpapers.com/images/high/abstract-nebula-psychedelic-4k-6diwrmh43ln4x0zz.webp"},
    {id:3, title:"Test", url:"https://wallpapers.com/images/featured/4k-oaax18kaapkokaro.webp"},
    {id:4, title:"Zdjęcie 4", url:"https://wallpapers.com/images/high/oman-mutrah-corniche-night-view-jwtbd5wge3ryqqoa.webp"}
  ]

  const [value, setValue] = useState("");
  function handleChange(e) {
      setValue(e.target.value);
  }

  return (
    <>
      <h1>Galeria</h1>
      <h3>Galeria zdjęć</h3>
      <input type="text" placeholder="Filtruj zdjęcia" value={value} onChange={handleChange}/>
      <div id="gallery-container">
        {
          images.map(image => {
            if(image.title.includes(value)) {
              return <div>
                <img src={image.url} alt={image.title}/>
                <h5>{image.title}</h5>
              </div>
            }
          })}
      </div>
    </>
  )
}

export default App
